const {STRING, INTEGER, BOOLEAN, DATE, Sequelize} = require('sequelize')

module.exports = {
	name: "CANDIDATES",
	freezeTableName: true,
	define: {
		MATRICULE: STRING,
		EMAIL: STRING,
		PHONE_NUMBER: STRING,
		LASTNAME: STRING,
		FIRSTNAME: STRING,
		COUNTRY: STRING,
		BIRTHDATE: STRING,
		BIRTHPLACE: STRING,
		STAB: STRING,
		GENDER: STRING,
		OLD_SPECIALITY: STRING,
		OLD_OBTENTION_YEAR: STRING,
		ACTIVATED: {
			type: BOOLEAN, defaultValue: false
		},
		HAS_EMAIL_VERIFIED: {
			type: BOOLEAN, defaultValue: false
		},
	}
}
