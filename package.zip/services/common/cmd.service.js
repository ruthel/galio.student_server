"use strict";
const fs = require("fs");
const path = require("path");

module.exports = {
	name: "cmd",
	actions: {
		runner: {
			async handler() {
				const envFilePath = path.join(__dirname, '..','..', ".env");
				const envContent = fs.readFileSync(envFilePath, "utf8");
				const envVariables = envContent
					.split("\n")
					.filter(line => line.trim() !== "")
					.reduce((acc, line) => {
						const [key, value] = line.split("=");
						acc[key] = value;
						return acc;
					}, {});
				envVariables.MY_API_KEY = "new-value";
				const updatedEnvContent = Object.entries(envVariables)
					.map(([key, value]) => `${key}=${value}`)
					.join("\n");
				fs.writeFileSync(envFilePath, updatedEnvContent, "utf8");
				console.log("Environment variable updated successfully!");
				const cronService = this.broker.getLocalService("imports");
				console.log(cronService.getJob('imp_classes'))
				// cronService.stop();
				// cronService.start();
			}
		}
	},
};
