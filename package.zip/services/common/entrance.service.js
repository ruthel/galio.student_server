"use strict";
const Entrance = require("../../models/common/Entrance");
const DbService = require("moleculer-db");
const adapter = require("../../adapter/mssql");

module.exports = {
	name: "entrance",
	mixins: [DbService],
	adapter,
	model: Entrance,
	actions: {
		model: {
			async handler() {
				return this.model
			}
		},
		listAll: {
			async handler() {
				return this.model
			}
		}
	},

	async started() {
		await this.adapter.model.sync({force: false})
	},

	stopped() {
	}
};
