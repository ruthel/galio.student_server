module.exports = {
  json: {limit: '1000mb', extended: true},
  urlencoded: {limit: '1000mb', extended: true}
}