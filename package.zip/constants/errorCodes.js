const errorCodes = {
  notUniq: 'not_unique'
}

module.exports = errorCodes